<!DOCTYPE html>
<!-- Milestone 7, Calista Ahlstrom: 05/25/21 -->
<!-- Generate an HTML Form for a failed Login response -->
<!-- References: Activity 6 Individual Assignment- CST-126, W3Schools, Stack Overflow -->
<html>
<head>
<meta charset="UTF-8">
<title>Login Failed!</title>
</head>
<body>
<h2><?php echo $message;
echo '<br><a href="milestoneLogin.html">Try Again</a>';?></h2>
</body>
</html>
