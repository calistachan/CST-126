<!DOCTYPE html>
<!-- Milestone 7, Calista Ahlstrom: 05/25/21 -->
<!-- Generate an HTML Form for a successful Admin Login response -->
<!-- References: Activity 6 Individual Assignment- CST-126, W3Schools, Stack Overflow -->
<html>
<head>
<meta charset="UTF-8">
<title>Hello Admin!</title>
</head>
<body>
	<h2>Login was successful, Admin: <?php echo " " . $email ?></h2>
	
	<a href="milestoneAdminFeed.php"> View All Posts </a>
	
	<a href="index.html">Log Out</a>
</body>
</html>
